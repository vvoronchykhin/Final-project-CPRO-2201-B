#Netflix Title Model - Represents movies and TV shows from the Netflix catalog.

from django.db import models


class NetflixTitle(models.Model):
    #Main model storing Netflix content metadata.
    TYPE_CHOICES = [
        ('Movie', 'Movie'),
        ('TV Show', 'TV Show'),
    ]
    
    show_id = models.CharField(max_length=20, unique=True, db_index=True)
    content_type = models.CharField(max_length=10, choices=TYPE_CHOICES, db_index=True)
    title = models.CharField(max_length=500, db_index=True)
    director = models.TextField(blank=True, null=True)
    cast = models.TextField(blank=True, null=True)
    country = models.TextField(blank=True, null=True)
    date_added = models.CharField(max_length=50, blank=True, null=True)
    release_year = models.IntegerField(blank=True, null=True, db_index=True)
    rating = models.CharField(max_length=20, blank=True, null=True, db_index=True)
    duration = models.CharField(max_length=50, blank=True, null=True)
    listed_in = models.TextField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-release_year', 'title']
        verbose_name = 'Netflix Title'
        verbose_name_plural = 'Netflix Titles'
        indexes = [
            models.Index(fields=['title', 'content_type']),
            models.Index(fields=['rating', 'release_year']),
        ]
    
    def __str__(self):
        return f"{self.title} ({self.release_year}) - {self.content_type}"
    
    def get_genres_list(self):
        #Returns genres as a list 
        if self.listed_in:
            return [genre.strip() for genre in self.listed_in.split(',')]
        return []
    
    def get_cast_list(self):
        #Returns first 5 cast members as a list
        if self.cast and self.cast != 'Unknown':
            return [actor.strip() for actor in self.cast.split(',')[:5]]
        return []
    
    def short_description(self):
        if self.description:
            return self.description[:150] + '...' if len(self.description) > 150 else self.description
        return 'No description available.'
