from django.core.management.base import BaseCommand
from django.db import models
from netflix_app.models import NetflixTitle
import pandas as pd
import os


class Command(BaseCommand):
    help = 'Loads Netflix data from CSV'
    
    def handle(self, *args, **options):
        # Locate CSV file 
        csv_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
            '..', 'netflix_titles.csv'
        )
        csv_path = os.path.normpath(csv_path)
        
        self.stdout.write("=" * 70)
        self.stdout.write(self.style.SUCCESS("NETFLIX DATA LOADER"))
        self.stdout.write("=" * 70)
        
        if not os.path.exists(csv_path):
            self.stdout.write(self.style.ERROR(f"[ERROR] CSV not found: {csv_path}"))
            return
        
        self.stdout.write(f"\n[1/4] Reading CSV...")
        try:
            df = pd.read_csv(csv_path)
            total_records = len(df)
            self.stdout.write(self.style.SUCCESS(f"      [OK] {total_records} records"))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"[ERROR] {str(e)}"))
            return
        
        self.stdout.write(f"\n[2/4] Cleaning data...")
        df['director'] = df['director'].fillna('Unknown')
        df['cast'] = df['cast'].fillna('Unknown')
        df['country'] = df['country'].fillna('Unknown')
        df['date_added'] = df['date_added'].fillna('')
        df['rating'] = df['rating'].fillna('Unrated')
        df['duration'] = df['duration'].fillna('Unknown')
        df['listed_in'] = df['listed_in'].fillna('Uncategorized')
        df['description'] = df['description'].fillna('')
        df['release_year'] = pd.to_numeric(df['release_year'], errors='coerce')
        self.stdout.write(self.style.SUCCESS(f"      [OK] Done"))
        
        self.stdout.write(f"\n[3/4] Clearing database...")
        deleted = NetflixTitle.objects.all().count()
        NetflixTitle.objects.all().delete()
        self.stdout.write(self.style.SUCCESS(f"      [OK] Deleted {deleted} old records"))
        
        self.stdout.write(f"\n[4/4] Loading to database...")
        batch_size = 1000  # Bulk insert for performance
        titles_to_create = []
        created_count = 0
        
        for index, row in df.iterrows():
            title = NetflixTitle(
                show_id=str(row['show_id']),
                content_type=row['type'],
                title=row['title'][:500] if pd.notna(row['title']) else 'Unknown',
                director=str(row['director']) if pd.notna(row['director']) else 'Unknown',
                cast=str(row['cast']) if pd.notna(row['cast']) else 'Unknown',
                country=str(row['country']) if pd.notna(row['country']) else 'Unknown',
                date_added=str(row['date_added']) if pd.notna(row['date_added']) else '',
                release_year=int(row['release_year']) if pd.notna(row['release_year']) else None,
                rating=str(row['rating']) if pd.notna(row['rating']) else 'Unrated',
                duration=str(row['duration']) if pd.notna(row['duration']) else 'Unknown',
                listed_in=str(row['listed_in']) if pd.notna(row['listed_in']) else 'Uncategorized',
                description=str(row['description']) if pd.notna(row['description']) else ''
            )
            titles_to_create.append(title)
            
            if len(titles_to_create) >= batch_size:
                NetflixTitle.objects.bulk_create(titles_to_create)
                created_count += len(titles_to_create)
                titles_to_create = []
                self.stdout.write(f"      > {created_count}/{total_records}", ending='\r')
        
        if titles_to_create:
            NetflixTitle.objects.bulk_create(titles_to_create)
            created_count += len(titles_to_create)
        
        self.stdout.write(self.style.SUCCESS(f"\n      [OK] Loaded {created_count} records"))
        
        total = NetflixTitle.objects.count()
        movies = NetflixTitle.objects.filter(content_type='Movie').count()
        tv_shows = NetflixTitle.objects.filter(content_type='TV Show').count()
        
        self.stdout.write("\n" + "=" * 70)
        self.stdout.write(f"\nTotal: {total}")
        self.stdout.write(f"Movies: {movies} ({movies/total*100:.1f}%)")
        self.stdout.write(f"TV Shows: {tv_shows} ({tv_shows/total*100:.1f}%)")
        
        top_ratings = NetflixTitle.objects.values('rating').annotate(
            count=models.Count('rating')
        ).order_by('-count')[:5]
        
        self.stdout.write(f"\nTop 5 Ratings:")
        for r in top_ratings:
            self.stdout.write(f"  {r['rating']}: {r['count']}")
        
        self.stdout.write("\n" + "=" * 70)
        self.stdout.write(self.style.SUCCESS("[SUCCESS] COMPLETE!"))
        self.stdout.write("=" * 70 + "\n")
