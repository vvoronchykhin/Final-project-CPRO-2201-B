
from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q, Count
from .models import NetflixTitle
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend for server-side rendering
import matplotlib.pyplot as plt
import io
import base64
from collections import Counter


def home(request):
    #Home page with summary stats and featured titles
    total_titles = NetflixTitle.objects.count()
    total_movies = NetflixTitle.objects.filter(content_type='Movie').count()
    total_tv_shows = NetflixTitle.objects.filter(content_type='TV Show').count()
    top_ratings = NetflixTitle.objects.values('rating').annotate(
        count=Count('rating')
    ).order_by('-count')[:5]
    featured_titles = NetflixTitle.objects.all().order_by('-release_year')[:6]
    
    context = {
        'total_titles': total_titles,
        'total_movies': total_movies,
        'total_tv_shows': total_tv_shows,
        'top_ratings': top_ratings,
        'featured_titles': featured_titles,
    }
    return render(request, 'netflix_app/home.html', context)


def browse(request):
    #Browse page with search and filtering capabilities
    titles = NetflixTitle.objects.all()
    
    # Search across title, director, and cast
    search_query = request.GET.get('search', '').strip()
    if search_query:
        titles = titles.filter(
            Q(title__icontains=search_query) |
            Q(director__icontains=search_query) |
            Q(cast__icontains=search_query)
        )
    
    content_type = request.GET.get('type', '')
    if content_type:
        titles = titles.filter(content_type=content_type)
    
    rating = request.GET.get('rating', '')
    if rating:
        titles = titles.filter(rating=rating)
    
    year = request.GET.get('year', '')
    if year:
        titles = titles.filter(release_year=year)
    
    country = request.GET.get('country', '')
    if country:
        titles = titles.filter(country__icontains=country)
    
    genre = request.GET.get('genre', '')
    if genre:
        titles = titles.filter(listed_in__icontains=genre)
    
    # Build filter options for dropdowns
    all_ratings_raw = NetflixTitle.objects.values_list('rating', flat=True).distinct()
    all_ratings = sorted(set([r for r in all_ratings_raw if r and 'min' not in r.lower()]))
    all_years = NetflixTitle.objects.exclude(release_year__isnull=True).values_list(
        'release_year', flat=True
    ).distinct().order_by('-release_year')
    
    all_genres_raw = NetflixTitle.objects.values_list('listed_in', flat=True)
    genres_set = set()
    for genres in all_genres_raw:
        if genres:
            for genre_item in genres.split(','):
                genres_set.add(genre_item.strip())
    all_genres = sorted(list(genres_set))
    
    all_countries_raw = NetflixTitle.objects.values_list('country', flat=True)
    countries_set = set()
    for countries in all_countries_raw:
        if countries and countries != 'Unknown':
            for country_item in countries.split(','):
                countries_set.add(country_item.strip())
    all_countries = sorted(list(countries_set))[:50]
    
    paginator = Paginator(titles, 20)
    page = request.GET.get('page', 1)
    
    try:
        titles_page = paginator.page(page)
    except PageNotAnInteger:
        titles_page = paginator.page(1)
    except EmptyPage:
        titles_page = paginator.page(paginator.num_pages)
    
    context = {
        'titles': titles_page,
        'search_query': search_query,
        'selected_type': content_type,
        'selected_rating': rating,
        'selected_year': year,
        'selected_country': country,
        'selected_genre': genre,
        'all_ratings': all_ratings,
        'all_years': all_years,
        'all_genres': all_genres,
        'all_countries': all_countries,
        'total_results': paginator.count,
    }
    return render(request, 'netflix_app/browse.html', context)


def title_detail(request, pk):
    #Detail page for a single title.
    title = get_object_or_404(NetflixTitle, pk=pk)
    context = {'title': title}
    return render(request, 'netflix_app/title_detail.html', context)


def statistics(request):
    #Statistics page with charts for ratings, types, and genres.
    ratings_data = NetflixTitle.objects.values('rating').annotate(
        count=Count('rating')
    ).order_by('-count')[:10]
    ratings_chart = generate_ratings_chart(ratings_data)
    
    type_data = NetflixTitle.objects.values('content_type').annotate(
        count=Count('content_type')
    )
    type_chart = generate_type_chart(type_data)
    
    all_genres_raw = NetflixTitle.objects.values_list('listed_in', flat=True)
    genres_list = []
    for genres in all_genres_raw:
        if genres:
            for genre in genres.split(','):
                genres_list.append(genre.strip())
    
    genre_counts = Counter(genres_list)
    top_genres = dict(genre_counts.most_common(10))
    genres_chart = generate_genres_chart(top_genres)
    
    total_titles = NetflixTitle.objects.count()
    total_movies = NetflixTitle.objects.filter(content_type='Movie').count()
    total_tv_shows = NetflixTitle.objects.filter(content_type='TV Show').count()
    
    context = {
        'ratings_chart': ratings_chart,
        'type_chart': type_chart,
        'genres_chart': genres_chart,
        'total_titles': total_titles,
        'total_movies': total_movies,
        'total_tv_shows': total_tv_shows,
    }
    return render(request, 'netflix_app/statistics.html', context)


# Each returns a base64-encoded PNG image string

def generate_ratings_chart(data):
    #Bar chart showing content distribution by rating.
    plt.figure(figsize=(10, 5))
    ratings = [item['rating'] for item in data]
    counts = [item['count'] for item in data]
    
    plt.bar(ratings, counts, color='#E50914', alpha=0.8, edgecolor='black')
    plt.xlabel('Rating', fontsize=12, fontweight='bold')
    plt.ylabel('Number of Titles', fontsize=12, fontweight='bold')
    plt.title('Content Distribution by Ratings', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45, ha='right')
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=100, bbox_inches='tight')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()
    
    return base64.b64encode(image_png).decode('utf-8')


def generate_type_chart(data):
    #Pie chart showing Movies vs TV Shows split.
    plt.figure(figsize=(7, 7))
    types = [item['content_type'] for item in data]
    counts = [item['count'] for item in data]
    
    colors = ['#E50914', '#564d4d']
    explode = (0.05, 0)
    plt.pie(counts, labels=types, autopct='%1.1f%%', startangle=90,
            colors=colors, explode=explode, shadow=True,
            textprops={'fontsize': 12, 'fontweight': 'bold'})
    plt.title('Movies vs TV Shows Distribution', fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=100, bbox_inches='tight')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()
    
    return base64.b64encode(image_png).decode('utf-8')


def generate_genres_chart(data):
    #Horizontal bar chart showing top 10 genres.
    plt.figure(figsize=(10, 6))
    genres = list(data.keys())
    counts = list(data.values())
    
    plt.barh(genres, counts, color='#E50914', alpha=0.8, edgecolor='black')
    plt.xlabel('Number of Titles', fontsize=12, fontweight='bold')
    plt.ylabel('Genre', fontsize=12, fontweight='bold')
    plt.title('Top 10 Most Common Genres', fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=100, bbox_inches='tight')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()
    
    return base64.b64encode(image_png).decode('utf-8')
