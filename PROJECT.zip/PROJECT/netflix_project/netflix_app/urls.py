#URL routes for the Netflix app
from django.urls import path
from . import views

app_name = 'netflix_app'

urlpatterns = [
    path('', views.home, name='home'),                      # Landing page
    path('browse/', views.browse, name='browse'),           # Search & filter
    path('title/<int:pk>/', views.title_detail, name='title_detail'),  # Single title
    path('statistics/', views.statistics, name='statistics'),  # Charts & stats
]
