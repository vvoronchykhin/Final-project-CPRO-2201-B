from django.urls import path, include

urlpatterns = [
    path('', include('netflix_app.urls')),
]
